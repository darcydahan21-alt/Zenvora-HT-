# ZENVORA HT — Starter pwojè

Sa a se yon baz aplikasyon React + Vite ki gen yon paj Dakèy, seksyon aprantisaj, koneksyon/enskripsyon Appwrite, kondisyon transparan ak enfòmasyon kontak.

## Sa ki deja ladan
- Yon sèl paj Dakèy ki gen navigasyon ak seksyon.
- Aparans navy, lò ak ble wa.
- Fòm enskripsyon/koneksyon ki konekte ak Appwrite lè konfigirasyon an fèt.
- Nimewo MonCash/NatCash itilizatè a konfime.
- Kondisyon sou transparans, done pèsonèl, misyon ak retrè.
- Yon zòn debaz pou chaje misyon ki pibliye.

## Limit enpòtan
Sa a se yon starter, li poko pare pou pwodiksyon. Li pa trete peman, li pa valide resi, li pa fè retrè, epi li pa bay salè. Pa mete yon modèl kote moun oblije achte nivo pou jwenn dwa fè travay oswa resevwa revni garanti. VIP ki peye, si yo ta egziste, dwe sèlman vann avantaj fòmasyon opsyonèl ki gen valè reyèl, san garanti revni. Travay ak misyon rekonpans yo dwe aksesib san frè pou antre nan travay, epi rekonpans dwe gen finansman verifye.

## Kòmanse
Gade `SETUP.md` pou etap Appwrite ak Cloudflare Pages.
