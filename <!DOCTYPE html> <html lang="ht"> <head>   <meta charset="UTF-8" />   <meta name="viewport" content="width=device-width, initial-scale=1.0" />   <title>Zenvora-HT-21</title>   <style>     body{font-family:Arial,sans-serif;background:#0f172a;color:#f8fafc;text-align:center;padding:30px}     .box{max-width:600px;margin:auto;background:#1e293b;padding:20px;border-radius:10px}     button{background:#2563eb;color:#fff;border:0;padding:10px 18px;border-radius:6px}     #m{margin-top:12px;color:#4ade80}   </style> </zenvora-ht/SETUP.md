# Gid enstalasyon ZENVORA HT sou telefòn oswa òdinatè

## 1. Sa w bezwen
- Yon pwojè Appwrite Cloud.
- Yon kont Cloudflare pou hosting.
- Yon navigatè entènèt.
- Fichye ZIP sa a.

## 2. Appwrite
1. Antre nan Appwrite Cloud epi kreye yon nouvo Project ki rele `ZENVORA HT`.
2. Nan Project Settings, kopye Project ID a.
3. Nan Platforms, ajoute Web Platform. Mete domèn Cloudflare ou apre ou fin pibliye sit la; pandan tès lokal, ajoute `localhost`.
4. Kreye yon Database. Kenbe Database ID a.
5. Kreye koleksyon sa yo:
   - `profiles`
   - `tasks`
   - `submissions`
   - `payments`
6. Pa mete okenn API key sekrè nan fichye frontend `.env`. Itilize Appwrite Functions pou aksyon administratè ak verifikasyon ki mande privilèj.

## 3. Konekte pwojè a
1. Fè yon kopi `.env.example` epi rele kopi a `.env`.
2. Ranplase `METE_PROJECT_ID_OU` ak Project ID ou.
3. Mete Database ID ou ak ID koleksyon yo.
4. Mete endpoint Appwrite ki koresponn ak rejyon pwojè ou a.
5. Enstale depandans yo epi teste:
   - `npm install`
   - `npm run dev`
   - `npm run build`

## 4. Sekirite anvan lansman
- Pa janm mete API key sekrè nan browser.
- Pa kite itilizatè chanje pwòp wòl yo.
- Admin dwe verifye sou sèvè/Function, pa sèlman nan React.
- Mete règ aksè minimòm sou chak koleksyon ak fichye.
- Sèvi ak fonksyon sèvè pou fikse dat Ayiti, limite misyon pa jou, korije repons epi anrejistre rezilta yo.
- Itilize `America/Port-au-Prince` sou sèvè; pa fè konfyans lè telefòn patisipan an.
- Fè tès ak kont tès anvan ou itilize done reyèl.
- Pa kolekte PIN, OTP, modpas oswa lòt sekrè MonCash/NatCash.
- Verifye non benefisyè ak resi nan chanèl ofisyèl anvan nenpòt peman.

## 5. Pibliye sou Cloudflare Pages
Pi bon metòd pou kòmanse se konekte repozitwa Git la ak Cloudflare Pages.
- Build command: `npm run build`
- Build output directory: `dist`
- Ajoute tout varyab `.env` yo nan Project Settings > Environment Variables.
- Apre premye deplwaman, ajoute domèn sit la nan Appwrite Web Platform.

## 6. Sa ki poko konstwi
- Modil admin ak verifikasyon wòl sou sèvè.
- Koleksyon Appwrite konplè ak tout attributes/indexes.
- Upload prèv peman ak pwosesis verifikasyon.
- Mòd retrè ak kontwòl balans.
- Plan misyon chak jou ak reset minwi sou sèvè.
- Jounal rezilta repons ak rapò admin.
- Tès sekirite, backup ak règleman konfidansyalite final.

Pa lanse aplikasyon an pou pran lajan jiskaske tout eleman sa yo fin bati, teste, epi kondisyon peman yo verifye.
