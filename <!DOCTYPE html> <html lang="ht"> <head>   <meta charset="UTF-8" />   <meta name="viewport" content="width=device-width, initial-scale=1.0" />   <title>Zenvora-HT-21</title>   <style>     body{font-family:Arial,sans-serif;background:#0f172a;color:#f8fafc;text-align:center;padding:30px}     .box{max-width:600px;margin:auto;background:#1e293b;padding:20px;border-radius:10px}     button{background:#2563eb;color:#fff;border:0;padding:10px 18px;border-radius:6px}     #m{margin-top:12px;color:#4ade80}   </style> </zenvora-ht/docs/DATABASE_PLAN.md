# Plan baz done Appwrite (bouyon)

## profiles
- userId (string, unique)
- fullName (string)
- status (enum: pending, active, suspended)
- role (enum: participant, admin) — se sèvè sèlman ki ka bay admin
- createdAt (datetime)

## tasks
- title (string)
- description (string)
- taskDate (string YYYY-MM-DD, Haiti local date)
- taskType (enum: lesson, quiz, video_review, exercise)
- published (boolean)
- points (integer)
- answerKey (pa janm bay kliyan an; kenbe nan fonksyon sèvè oswa koleksyon prive)

## submissions
- userId (string)
- taskId (string)
- answer (string)
- isCorrect (boolean)
- pointsAwarded (integer)
- submittedAt (datetime)
- localTaskDate (string YYYY-MM-DD)

## payments
- userId (string)
- paymentType (enum: optional_service, reward_payout)
- method (enum: moncash, natcash)
- amountGds (integer)
- transactionReference (string)
- proofFileId (string, optional)
- status (enum: pending, approved, rejected, paid)
- reviewedBy (string)
- reviewedAt (datetime)

## Pèmisyon
Koleksyon yo dwe prive pa defo. Itilizatè ka li pwòp pwofil/rezilta yo sèlman. Se Appwrite Function ki dwe valide soumisyon, kalkile repons, limite aktivite pa jou ak fè aksyon admin. Pa mete `answerKey` nan koleksyon piblik.
