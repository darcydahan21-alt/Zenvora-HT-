# Règ pwodwi ZENVORA HT — bouyon pou revizyon

## Paj piblik
- Yon sèl paj Dakèy aksesib pou tout moun.
- Prezante sèvis la, fòmasyon, règ, kontak ak opòtinite ki verifye.
- Pa prezante revni kòm garanti.

## Kont ak misyon
- Enskripsyon debaz gratis.
- Moun pa dwe oblije peye pou aplike nan yon travay oswa jwenn aksè ak opòtinite travay.
- Misyon aprantisaj ka gen nivo difikilte; nivo peye pa dwe sèvi kòm kondisyon pou touche lajan.
- Misyon chak jou chanje sou dat sèvè a nan zòn `America/Port-au-Prince`.
- Chak repons dwe anrejistre avèk itilizatè, misyon, repons, rezilta, pwen ak lè.
- Lè limit aktivite jounen an fini, montre yon mesaj felisitasyon epi fèmen nouvo misyon jiskaske pwochen jou lokal la.
- Rezilta yo dwe rete disponib nan kont patisipan an ak nan rapò administratè a.

## Rekonpans
- Nenpòt rekonpans dwe gen finansman verifye anvan li pibliye.
- Montan rekonpans lan, kritè validasyon ak dat peman dwe parèt anvan patisipasyon.
- Pa pwomèt 170 GDS oswa 300 GDS pa jou kòm revni fiks.
- Pa peye pou fo abònman, like, follow oswa lòt angajman atifisyèl sou rezo sosyal.

## VIP
- VIP 1, VIP 2, VIP 3 ka sèvi kòm etikèt nivo aprantisaj gratis.
- Sèvis VIP peye, si yo ta ofri, dwe opsyonèl, dekri klèman epi bay valè fòmasyon/karakteristik reyèl.
- Acha VIP pa dwe achte aksè pou travay oswa dwa pou touche plis lajan.
- Pri, sa ki enkli, kondisyon ranbousman ak dire dwe parèt anvan peman.

## Retrè
- Minimòm demann retrè: 500 GDS, sèlman pou balans rekonpans ki finanse epi verifye.
- Maksimòm: balans disponib ki verifye; pa gen plafon fiks si bidjè a pèmèt.
- Metòd: MonCash ak NatCash.
- Chak demann dwe gen estati ak tras verifikasyon.
- Pa janm mande PIN, OTP oswa modpas.

## Kontak peman itilizatè a bay
- MonCash: +509 4935 0667
- NatCash: +509 3202 5495

Nimewo sa yo bezwen verifikasyon pwopriyetè/benefisyè sou chanèl ofisyèl yo anvan piblikasyon.
