# Appwrite Functions ki nesesè anvan lansman

Kreye fonksyon sèvè pou:
1. `submit-task`: verifye kont, dat Ayiti, limit misyon, korije repons, anrejistre rezilta.
2. `get-daily-tasks`: bay sèlman misyon jounen an ki pibliye pou itilizatè a.
3. `admin-review`: valide peman oswa demann retrè apre verifye wòl admin sou sèvè.
4. `daily-report`: bay admin rapò patisipan, repons, pwen ak lè.

Pa mete kle repons, API key oswa privilèj admin nan aplikasyon React. Fè fonksyon yo itilize secret ki estoke nan anviwònman Appwrite Functions. Fè tès otorizasyon pou asire yon patisipan pa ka chanje rezilta, balans oswa wòl li.
