import { Client, Account, Databases, Storage, ID, Query } from "appwrite";

const endpoint = import.meta.env.VITE_APPWRITE_ENDPOINT;
const projectId = import.meta.env.VITE_APPWRITE_PROJECT_ID;

export const configured = Boolean(endpoint && projectId && !projectId.includes("METE_"));

const client = new Client();
if (configured) client.setEndpoint(endpoint).setProject(projectId);

export const account = new Account(client);
export const databases = new Databases(client);
export const storage = new Storage(client);
export { ID, Query };
export const databaseId = import.meta.env.VITE_APPWRITE_DATABASE_ID;
export const collections = {
  tasks: import.meta.env.VITE_APPWRITE_TASKS_COLLECTION_ID || "tasks",
  submissions: import.meta.env.VITE_APPWRITE_SUBMISSIONS_COLLECTION_ID || "submissions",
  profiles: import.meta.env.VITE_APPWRITE_PROFILES_COLLECTION_ID || "profiles",
  payments: import.meta.env.VITE_APPWRITE_PAYMENTS_COLLECTION_ID || "payments"
};
export const bucketId = import.meta.env.VITE_APPWRITE_BUCKET_ID || "payment-proofs";
