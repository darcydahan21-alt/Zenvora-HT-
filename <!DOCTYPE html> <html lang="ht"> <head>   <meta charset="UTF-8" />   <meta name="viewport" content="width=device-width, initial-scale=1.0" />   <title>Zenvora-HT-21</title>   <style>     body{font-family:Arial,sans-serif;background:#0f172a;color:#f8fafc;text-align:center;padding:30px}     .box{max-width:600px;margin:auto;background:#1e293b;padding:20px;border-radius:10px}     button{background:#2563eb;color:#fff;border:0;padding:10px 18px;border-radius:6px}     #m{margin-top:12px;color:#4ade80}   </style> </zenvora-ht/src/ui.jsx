import React, { useState } from "react";
import { account, configured, databases, databaseId, collections, ID, Query } from "./appwrite.js";
import { BookOpen, BriefcaseBusiness, ShieldCheck, Menu, X, LogIn, UserPlus, Wallet, CircleHelp, CheckCircle2, Clock3 } from "lucide-react";

const CONTACT = { moncash: "+509 4935 0667", natcash: "+509 3202 5495" };

function Logo() {
  return <div className="brand">
    <div className="brand-mark">Z</div>
    <div><strong>ZENVORA <span>HT</span></strong><small>HAITIAN DIGITAL LEARNING PLATFORM</small></div>
  </div>;
}

export default function App() {
  const [menu, setMenu] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);

  async function signUp(e) {
    e.preventDefault();
    if (!configured) return setNotice("Appwrite poko konekte. Swiv etap SETUP.md yo anvan ou kreye kont.");
    setBusy(true);
    try {
      await account.create(ID.unique(), email, password, name);
      await account.createEmailPasswordSession(email, password);
      const current = await account.get();
      setUser(current);
      setNotice("Kont ou kreye. Verifye imel ou si administratè a mande sa.");
    } catch (err) { setNotice(err.message || "Nou pa kapab kreye kont lan kounye a."); }
    finally { setBusy(false); }
  }

  async function signIn(e) {
    e.preventDefault();
    if (!configured) return setNotice("Appwrite poko konekte. Swiv etap SETUP.md yo anvan ou konekte.");
    setBusy(true);
    try {
      await account.createEmailPasswordSession(email, password);
      setUser(await account.get());
      setNotice("Ou konekte avèk siksè.");
    } catch (err) { setNotice(err.message || "Enfòmasyon koneksyon yo pa kòrèk."); }
    finally { setBusy(false); }
  }

  async function loadTasks() {
    if (!configured || !databaseId || !user) return;
    try {
      const result = await databases.listDocuments(databaseId, collections.tasks, [
        Query.equal("published", true), Query.limit(50)
      ]);
      setTasks(result.documents);
    } catch { setNotice("Misyon yo poko disponib. Verifye baz done a oswa kontakte administratè a."); }
  }

  async function signOut() {
    try { await account.deleteSession("current"); } catch {}
    setUser(null); setTasks([]); setNotice("Ou dekonekte.");
  }

  return <div className="app-shell">
    <header className="topbar">
      <Logo />
      <button className="menu-btn" onClick={() => setMenu(!menu)} aria-label="Louvri meni">{menu ? <X/> : <Menu/>}</button>
      <nav className={menu ? "nav open" : "nav"}>
        <a href="#akèy" onClick={() => setMenu(false)}>Akèy</a>
        <a href="#aprann" onClick={() => setMenu(false)}>Aprann</a>
        <a href="#opòtinite" onClick={() => setMenu(false)}>Opòtinite</a>
        <a href="#kondisyon" onClick={() => setMenu(false)}>Kondisyon</a>
        <a href="#kontak" onClick={() => setMenu(false)}>Kontak</a>
      </nav>
      {user ? <button className="btn btn-outline" onClick={signOut}>Dekonekte</button> : <a className="btn btn-gold" href="#kont">Konekte / Enskri</a>}
    </header>

    <main>
      <section className="hero" id="akèy">
        <div className="hero-copy">
          <div className="eyebrow"><span className="dot"></span> PLATFÒM DIJITAL AYISYEN</div>
          <h1>Aprann. Devlope.<br/><em>Prepare demen ou.</em></h1>
          <p>ZENVORA HT mete fòmasyon, egzèsis ak enfòmasyon sou opòtinite travay sou entènèt nan yon sèl espas.</p>
          <div className="hero-actions">
            <a href="#kont" className="btn btn-gold">Kreye kont gratis <UserPlus size={17}/></a>
            <a href="#aprann" className="btn btn-outline">Dekouvri platfòm nan</a>
          </div>
          <p className="micro">Kreye kont la gratis. Li kondisyon yo anvan ou patisipe nan nenpòt aktivite ki gen frè.</p>
        </div>
        <div className="hero-art" aria-label="ZENVORA HT">
          <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <div className="hero-emblem">Z<span>+</span></div>
          <div className="hero-caption">ZENVORA <b>HT</b><small>APRANN • DEVLOPE • TRAVAY</small></div>
        </div>
      </section>

      <section className="trust-strip">
        <div><ShieldCheck/><span>Enfòmasyon klè</span></div>
        <div><BookOpen/><span>Aprantisaj ak egzèsis</span></div>
        <div><BriefcaseBusiness/><span>Opòtinite verifye</span></div>
      </section>

      <section className="section" id="aprann">
        <div className="section-heading"><span className="eyebrow">SA W AP JWENN</span><h2>Yon espas pou devlope kapasite ou</h2><p>Tout aktivite dwe gen objektif, règ ak kondisyon ki fasil pou konprann.</p></div>
        <div className="feature-grid">
          <article className="feature"><div className="feature-icon"><BookOpen/></div><h3>Fòmasyon</h3><p>Leson, videyo, kilti jeneral, matematik ak lòt egzèsis pou aprann.</p></article>
          <article className="feature"><div className="feature-icon"><CheckCircle2/></div><h3>Misyon ak egzèsis</h3><p>Repons yo ka korije otomatikman. Rezilta yo parèt klè pou patisipan an.</p></article>
          <article className="feature"><div className="feature-icon"><BriefcaseBusiness/></div><h3>Opòtinite travay</h3><p>Enfòmasyon sou travay dwe verifye, ak responsablite, kondisyon ak kontak klè.</p></article>
        </div>
      </section>

      <section className="section dark-section" id="kont">
        <div className="section-heading"><span className="eyebrow">ESPAS PATISIPAN</span><h2>Kreye kont ou oswa konekte</h2><p>Ou ka kreye yon kont san peye. Pa janm voye modpas ou bay pèsonn.</p></div>
        <form className="auth-card" onSubmit={signIn}>
          <label>Imèl<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="egzanp@email.com"/></label>
          <label>Modpas<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength="8" placeholder="Omwen 8 karaktè"/></label>
          <button className="btn btn-gold full" type="submit" disabled={busy}><LogIn size={17}/> Konekte</button>
          <div className="form-divider">OSWA KREYE YON KONT</div>
          <label>Non konplè<input value={name} onChange={e=>setName(e.target.value)} placeholder="Non ak siyati"/></label>
          <button className="btn btn-outline full" type="button" disabled={busy} onClick={signUp}><UserPlus size={17}/> Enskri gratis</button>
          {notice && <p className="notice" role="status">{notice}</p>}
          {!configured && <p className="warning">Mòd demonstrasyon: konekte Appwrite nan fichye .env pou aktive kont yo.</p>}
        </form>
        {user && <div className="member-panel">
          <h3>Byenveni, {user.name || user.email}</h3>
          <p>Kont ou konekte. Misyon yo ap parèt lè baz done a, validasyon aksè ak fonksyon sekirite yo fin konfigire.</p>
          <button className="btn btn-outline" onClick={loadTasks}>Chaje misyon disponib</button>
          {tasks.map(t=><article className="task" key={t.$id}><b>{t.title}</b><p>{t.description}</p></article>)}
        </div>}
      </section>

      <section className="section" id="kondisyon">
        <div className="section-heading"><span className="eyebrow">TRANSPARANS</span><h2>Règ ak kondisyon</h2><p>Li tout kondisyon yo anvan ou patisipe.</p></div>
        <div className="rules">
          <article><h3>Kont ak aksè</h3><p>Kreye kont la gratis. Nenpòt frè pou fòmasyon oswa sèvis dwe parèt klè anvan peman, avèk sa frè a kouvri. Pa peye pou jwenn yon travay oswa pou resevwa yon salè garanti.</p></article>
          <article><h3>Misyon ak rekonpans</h3><p>Chak misyon dwe presize travay la, delè a, kritè validasyon an ak si gen rekonpans. Rekonpans pa garanti; yo peye sèlman lè gen finansman ak kondisyon yo satisfè.</p></article>
          <article><h3>VIP ak acha</h3><p>Pa gen nivo VIP ki bay garanti revni oswa ki mande acha pou jwenn aksè ak travay. Nenpòt sèvis peye dwe opsyonèl, ak pri, avantaj, ranbousman ak kondisyon anvan acha.</p></article>
          <article><h3>Retrè</h3><p>Si gen yon pwogram rekonpans finanse, minimòm demann retrè a se 500 GDS. Maksimòm lan limite ak balans verifye ki disponib. Demann yo pase nan verifikasyon.</p></article>
          <article><h3>Done pèsonèl</h3><p>Nou itilize enfòmasyon sèlman pou jere kont ak aktivite platfòm nan. Pa mete modpas, PIN MonCash/NatCash oswa kòd sekirite nan prèv peman.</p></article>
          <article><h3>Reklamasyon</h3><p>Patisipan an ka kontakte administrasyon an pou kesyon sou kont, rezilta oswa tranzaksyon. Kenbe resi ak nimewo referans tranzaksyon yo.</p></article>
        </div>
      </section>

      <section className="section payment-section" id="kontak">
        <div className="section-heading"><span className="eyebrow">KONTAK ADMINISTRASYON</span><h2>Kontakte ZENVORA HT</h2><p>Nimewo sa yo se enfòmasyon kontak/peman itilizatè a bay. Verifye non benefisyè a nan aplikasyon ofisyèl la anvan ou voye lajan.</p></div>
        <div className="contact-grid">
          <div className="contact-card"><span className="payment-label">MONCASH</span><strong>+509 4935 0667</strong><a href="tel:+50949350667">Rele nimewo a</a></div>
          <div className="contact-card"><span className="payment-label">NATCASH</span><strong>+509 3202 5495</strong><a href="tel:+50932025495">Rele nimewo a</a></div>
        </div>
        <p className="notice">Pa pataje PIN, modpas, OTP oswa kòd konfimasyon ak pèsonn. Paj sa a poko trete peman otomatik.</p>
      </section>
    </main>

    <footer><Logo/><p>© {new Date().getFullYear()} ZENVORA HT. Tout dwa rezève.</p><small>Aprann • Devlope • Travay</small></footer>
  </div>;
}
